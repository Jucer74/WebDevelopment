﻿namespace MoneyBankMVC.Services;

public interface IAccountService
{
}