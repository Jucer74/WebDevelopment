﻿namespace MoneyBankMVC.Services;

public class AccountService : IAccountService
{
}
