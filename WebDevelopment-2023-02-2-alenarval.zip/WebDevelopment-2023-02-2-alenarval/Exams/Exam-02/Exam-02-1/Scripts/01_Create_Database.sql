CREATE DATABASE `moneybankdb`;
