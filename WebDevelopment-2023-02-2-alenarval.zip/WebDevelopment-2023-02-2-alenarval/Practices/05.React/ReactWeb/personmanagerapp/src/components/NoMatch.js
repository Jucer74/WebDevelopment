import React from 'react';

export const NoMatch = () => (
  <h1>No Match Found</h1>
)