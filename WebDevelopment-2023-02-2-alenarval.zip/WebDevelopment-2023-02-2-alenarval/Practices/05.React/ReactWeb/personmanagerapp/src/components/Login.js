import React from 'react';

export const Login = () => (
  <h1>Login</h1>
)