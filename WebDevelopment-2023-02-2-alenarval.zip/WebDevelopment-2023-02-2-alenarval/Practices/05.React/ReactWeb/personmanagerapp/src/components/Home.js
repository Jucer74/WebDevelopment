import React from 'react';

export const Home = () => (
  <h1>Home</h1>
)