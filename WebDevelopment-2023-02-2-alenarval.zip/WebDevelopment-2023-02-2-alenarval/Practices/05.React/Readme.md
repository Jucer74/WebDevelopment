Que es el DOM
=============
https://www.freecodecamp.org/espanol/news/que-es-el-dom-el-significado-del-modelo-de-objeto-de-documento-en-javascript/

Refuerzo de JavaScript
========================
https://www.youtube.com/watch?v=lVqHiTCIRQg&list=RDCMUCX9NJ471o7Wie1DQe94RVIg&index=2

ReactJs - Introduction
======================
https://react.dev/
https://egghead.io/q/react
https://react.dev/learn

https://legacy.reactjs.org/tutorial/tutorial.html
https://www.w3schools.com/REACT/DEFAULT.ASP


ReactJs - Hooks
======================
https://www.youtube.com/playlist?list=PLGfh-NC9-wCdmiy4NHMKEZFi2nENAmpX-

Use Boostrap in ReactJs
=======================
https://www.kindacode.com/article/how-to-use-bootstrap-5-and-bootstrap-icons-in-react/


Login Form in ReactJS with React Hooks
======================================
https://www.youtube.com/watch?v=91qEdc6dSUs
https://www.youtube.com/watch?v=QoLUB0QkUaE&t=355s
https://www.youtube.com/watch?v=EbUNgXQIqrk
https://www.youtube.com/watch?v=4BhhGs0PFHU

Que es Redux
============
http://blog.enriqueoriol.com/2018/08/que-es-redux.html


React with a Web API
====================
https://www.youtube.com/watch?v=noX75vnFrYc&list=PLN1yQDPWR2SMcMsO7QzMCC_g_sYr4K76Q