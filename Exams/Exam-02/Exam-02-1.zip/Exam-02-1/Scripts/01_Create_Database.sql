CREATE DATABASE `moneybankdb`;
