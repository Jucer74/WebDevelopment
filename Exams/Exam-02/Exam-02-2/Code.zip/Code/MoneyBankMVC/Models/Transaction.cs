﻿namespace MoneyBankMVC.Models
{
    public class Transaction : Account
    {
        
        public decimal ValueAmount { get; set; }

    }
}
