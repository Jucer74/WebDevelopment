# Evaluación Teórica (40%)
Responda las preguntas del siguiente Enlace:

[Examen]()

# Ejercicio (60%)
Utilizando **Bootstrap 5** , complete la pagina **Portafolio.html** de forma que cumpla con las siguientes características:

## Home
![Home](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Home.jpg)

## Resume
![Resume](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Resume.jpg)

## Work
![Work](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Work.jpg)

## Contact
![Contact](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Contact.jpg)

### Codigo
recuerde Subir los cambios a su rama en esta misma ruta.
**.../Exams/Exam-01**
