﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Parcial.Controllers
{
    public class HomeController1 : Controller
    {
        // GET: Register
        public ActionResult Index()
        {
            return View();
        }


    }
}
