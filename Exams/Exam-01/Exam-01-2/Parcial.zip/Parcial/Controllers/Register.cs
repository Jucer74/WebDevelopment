﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Parcial.Controllers
{
    public class Register : Controller
    {
        // GET: Register
        public ActionResult Index()
        {
            return View();
        }

        
    }
}
