from pydantic import BaseModel
from datetime import datetime

class AccountSchema(BaseModel):
    Id: int
    AccountTyper: str
    CreationDate: datetime
    AccountNumber: str
    OwnerName: str
    BalanceAccount = float
    OverdraftAmount=float


