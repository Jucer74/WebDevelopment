from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from Models.AccountModel import AccountModel
from Schemas.AccountSchema import AccountSchema
from Config.database import SessionLocal


@app.post("/accounts/", response_model=Account)
def create_account(account: AccountCreate, db: Session = Depends(get_db)):
    db_account = Account(**account.dict())
    db.add(db_account)
    db.commit()
    db.refresh(db_account)
    return db_account

@app.get("/accounts/", response_model=list[Account])
def list_accounts(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    accounts = db.query(Account).offset(skip).limit(limit).all()
    return accounts

@app.get("/accounts/{account_id}", response_model=Account)
def get_account(account_id: int, db: Session = Depends(get_db)):
    account = db.query(Account).filter(Account.Id == account_id).first()
    if account is None:
        raise HTTPException(status_code=404, detail="Account not found")
    return account

@app.put("/accounts/{account_id}", response_model=Account)
def update_account(account_id: int, account_update: AccountUpdate, db: Session = Depends(get_db)):
    db_account = db.query(Account).filter(Account.Id == account_id).first()
    if db_account is None:
        raise HTTPException(status_code=404, detail="Account not found")
    
    for key, value in account_update.dict().items():
        setattr(db_account, key, value)
    
    db.commit()
    db.refresh(db_account)
    return db_account

@app.post("/accounts/{account_id}/deposit/", response_model=Account)
def deposit_to_account(account_id: int, amount: float, db: Session = Depends(get_db)):
    db_account = db.query(Account).filter(Account.Id == account_id).first()
    if db_account is None:
        raise HTTPException(status_code=404, detail="Account not found")
    
    db_account.BalanceAmount += amount
    db.commit()
    db.refresh(db_account)
    return db_account

@app.post("/accounts/{account_id}/withdraw/", response_model=Account)
def withdraw_from_account(account_id: int, amount: float, db: Session = Depends(get_db)):
    db_account = db.query(Account).filter(Account.Id == account_id).first()
    if db_account is None:
        raise HTTPException(status_code=404, detail="Account not found")
    
    if db_account.BalanceAmount < amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")
    
    db_account.BalanceAmount -= amount
    db.commit()
    db.refresh(db_account)
    return db_account

@app.delete("/accounts/{account_id}", response_model=Account)
def delete_account(account_id: int, db: Session = Depends(get_db)):
    db_account = db.query(Account).filter(Account.Id == account_id).first()
    if db_account is None:
        raise HTTPException(status_code=404, detail="Account not found")
    
    db.delete(db_account)
    db.commit()
    return db_account