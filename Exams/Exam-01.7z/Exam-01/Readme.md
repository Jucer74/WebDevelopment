# Evaluación Teórica (40%)
Responda las preguntas del siguiente Enlace:

[Examen]()

# Ejercicio (60%)
Utilizando **Bootstrap 5** , complete la pagina **Portafolio.html** de forma que cumpla con las siguientes características:

## Home
![Home](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Home.jpg)

### Funcional
- No esta la pagina
### Codigo
## Resume
![Resume](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Resume.jpg)

### Funcional
- No esta la pagina
### Codigo
## Work
![Work](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Work.jpg)

### Funcional
- No esta la pagina
### Codigo
## Contact
![Contact](https://github.com/Jucer74/WebDevelopment/blob/main/Exams/Exam-01/Plantillas/Contact.jpg)

### Funcional
### Codigo

recuerde Subir los cambios a su rama en esta misma ruta.
**.../Exams/Exam-01**