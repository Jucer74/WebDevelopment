﻿namespace WebDev.Config
{
    public class ApiConfiguration
    {
        public string ApiUsersUrl { get; set; }
        public string ApiLoginUrl { get; set; }
    }
}